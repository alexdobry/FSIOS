//
//  ViewController.swift
//  Switcheroo
//
//  Created by Dennis Dubbert on 06.05.17.
//  Copyright © 2017 Dennis Dubbert. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var secondsLeft: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var pictureLabel: UILabel!
    
    var myTimer: SwitchTimer?
    var directionManager: DirectionManager?
    var active = false
    var finished = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //register swipes
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = .down
        self.view.addGestureRecognizer(swipeDown)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeUp.direction = .up
        self.view.addGestureRecognizer(swipeUp)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
        
    
        myTimer = SwitchTimer(initialTime: 0)
        secondsLeft.text = "\(myTimer!.timeLeft)"
        myTimer!.delegate = self
        directionManager = DirectionManager(timer: myTimer!, delegateTo: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func startPressed(_ sender: Any) {
        if finished{
            reset()
        }else{
            directionManager?.createDirections()
        }
        myTimer?.runTimer()
        active = true
    }
    
    func reset(){
        progressBar.setProgress(1, animated: false)
        directionManager?.reset()
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        guard active == true else{return}
        
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            
            
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                    directionManager?.checkDirectionInput(Directions.right)
            
            case UISwipeGestureRecognizerDirection.down:
                    directionManager?.checkDirectionInput(Directions.down)
                
            case UISwipeGestureRecognizerDirection.left:
                    directionManager?.checkDirectionInput(Directions.left)
                
            case UISwipeGestureRecognizerDirection.up:
                    directionManager?.checkDirectionInput(Directions.up)
                
            default:
                break
            }
        }
    }
}

extension ViewController: SwitchTimerDelegate, DirectionManagerDelegate {
    
    func timerDidChange(to seconds: Float, withMax max: Float) {
        if seconds > 0.01 {
            let twoDecimalPlaces = String(format: "%.2f", seconds)
            let progress = seconds / max
            
            secondsLeft.text = "\(twoDecimalPlaces)"
            progressBar.setProgress(progress, animated: true)
        }else{
            if active{
                progressBar.setProgress(0, animated: true)
                secondsLeft.text = "0.00"
            }
        }
    }
    
    func gameOver(){
        directionManager?.stopGame()
    }
    
    func directionChanged(direction: String){
        pictureLabel.text = direction
    }
    
    func finishedDirections(score: Int){
        finished = true
        active = false
        pictureLabel.text = "Score: \(score)"
    }
}
